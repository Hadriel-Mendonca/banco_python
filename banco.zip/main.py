LIMITE_SAQUES = 3
numero_saques = 0
saldo = 0
limite = 500
extrato = ""

menu = """Olá, seja bem vindo ao nosso banco. Escolha uma das opções abaixo:

1 -> Sacar
2 -> Depositar
3 -> Extrato
4 -> Sair

"""

while True:
  operação = input(menu)

  if operação == "1":
    valor_saque = float(input("Informe o valor do saque: "))
    if valor_saque > limite:
      print("O valor do saque excede o limite de R$500,00")
    elif valor_saque <= 0:
      print("Informe um valor positivo")
    elif numero_saques == LIMITE_SAQUES:
      print("Você atingiu o limite de saques diários")
    elif valor_saque > saldo:
      print("Saldo insuficiente")
    else:
        saldo -= valor_saque
        print("Saque realizado com sucesso")
        print(f"Saldo atual: R$ {saldo:.2f}")
        numero_saques += 1
        extrato += f"Saque de R$ {valor_saque:.2f}\n"
  elif operação == "2":
    valor_deposito = float(input("Informe o valor do depósito: "))
    if valor_deposito <= 0:
      print("Informe um valor positivo")
    else:
      saldo += valor_deposito
      print("Depósito realizado com sucesso")
      print(f"Saldo atual: R$ {saldo:.2f}")
      extrato += f"Depósito de R$ {valor_deposito:.2f}\n"
  elif operação == "3":
    print("------>Extrato<------\n")
    print(extrato)
    print(f"Saldo atual: R$ {saldo:.2f}")
  elif operação == "4":
    print("Obrigado por utilizar nosso banco!")
    break
  else:
    print("Informe uma opção válida")